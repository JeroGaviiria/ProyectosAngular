import { Component } from '@angular/core';

@Component({
  selector: 'app-triangulo',
  templateUrl: './triangulo.component.html',
  styleUrls: ['./triangulo.component.css']
})
export class TrianguloComponent {
  valor: number = 1;
  valor2: number = 4;
  valor3: number = 7;
  constructor() {}


  ngOnInit() {
    this.valor = Math.trunc(Math.random() * 6) + 1;
    this.valor2 = Math.trunc(Math.random() * 6) + 2;
    this.valor3 = Math.trunc(Math.random() * 6) + 3;
  }}