import { Component } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent {
  barra = '';
  calculadoraPrendida = true;
  posicionBarra = 0;

  borrar() {
    this.barra = '';
  }

  apagar() {
    this.barra = 'Apagada';
    this.calculadoraPrendida = false;
  }

  calcular() {
    if (this.calculadoraPrendida) {
      let resultado = '';
      
      resultado = eval(`${this.barra}`);
        
      this.barra = `${resultado}`;
    }
  }

  estadoCalculadora() {
    this.calculadoraPrendida = !this.calculadoraPrendida;
    if (!this.calculadoraPrendida) {
      this.apagar();
    } else {
      this.barra = '';
      this.posicionBarra = 0; 
    }
  }

  navegarIzquierda() {
    if (!this.calculadoraPrendida) {
      return;
    }
    if (this.posicionBarra > 0) {
      this.posicionBarra--;
    }
  }

  navegarDerecha() {
    if (!this.calculadoraPrendida) {
      return;
    }
    if (this.posicionBarra < this.barra.length) {
      this.posicionBarra++;
    }
  }

  borrarCaracter() {
    if (!this.calculadoraPrendida) {
      return;
    }
    if (this.posicionBarra > 0) {
      this.barra = this.barra.slice(0, this.posicionBarra - 1) + this.barra.slice(this.posicionBarra);
      this.posicionBarra--;
    }
  }
 
  ponerNumero(num: string) {
    if (!this.calculadoraPrendida) {
      return;
    }
    this.barra = this.barra.slice(0, this.posicionBarra) + num + this.barra.slice(this.posicionBarra);
    this.posicionBarra++;
  }

  ponerOperacion(operador: string) {
    if (!this.calculadoraPrendida) {
      return;
    }
    this.barra =
      this.barra.slice(0, this.posicionBarra) +
      operador +
      this.barra.slice(this.posicionBarra);
    this.posicionBarra += operador.length;
  }

  obtenerCursorEnInput() {
    let cursorEnInput = this.barra;
    if (this.posicionBarra > 0) {
      cursorEnInput = cursorEnInput.slice(0, this.posicionBarra) + '|' + cursorEnInput.slice(this.posicionBarra);
    } else {cursorEnInput
      cursorEnInput = '|' + cursorEnInput;
    }
    return cursorEnInput;
  }
}
