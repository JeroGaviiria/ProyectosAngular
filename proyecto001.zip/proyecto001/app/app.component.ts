import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  suma = 10+5;
  resta = 10-5;
  multiplicacion = 10*5;
  division = 10/5;
}

